package com.citi.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
/*
 * @ComponentScans(value = { @ComponentScan("com.cg.srm.repository"),
 * 
 * @ComponentScan("com.cg.srm.service") })
 */
@ComponentScan("com.citi.demo") // @Service, @Repository,@Component
public class Test {
	public static void main(String[] args) {

//		Resource resource = new ClassPathResource("springconfig.xml");
//
//		BeanFactory factory = new XmlBeanFactory(resource);//LAZY

		ApplicationContext factory = new AnnotationConfigApplicationContext(Test.class);

		Employee emp = (Employee) factory.getBean("emp");
		System.out.println(emp + " " + emp.getAddress());// singleton,prototype,request,session,global-session
		// @Bean
	}

	@Bean("emp")//<bean>
	public Employee getEmployee() {
		Employee emp = new Employee();
		emp.setAddress(getAddress());
		return emp;

	}

	@Bean
	public Address getAddress() {
		return new Address();
	}

}
