package com.example.demo.repsitory;

import java.util.List;

import com.example.demo.entity.Employee;

public interface EmployeeDAOI  {
//DATAJPA-->CrudRepository,JpaRepository
	String deleteById(int id);

	List<Employee> getAllEmployee();

	Employee getEmployeeById(int id);

	String EmployeeCreation(Employee emp);

	String UpdateEmployee(Employee emp);
}
