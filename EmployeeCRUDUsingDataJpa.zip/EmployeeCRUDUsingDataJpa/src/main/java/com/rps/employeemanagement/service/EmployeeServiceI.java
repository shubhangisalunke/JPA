package com.rps.employeemanagement.service;

import java.util.List;

import com.rps.employeemanagement.entity.Employee;

public interface EmployeeServiceI {
	String deleteByEmpId(int id);

	List<Employee> getAllEmployee();

	Employee getEmployeeById(int id);

	String EmployeeCreation(Employee emp);

	String UpdateEmployee(Employee emp);

	public List<Employee> getAllEmpsInBetween(long initialSal, long salary);

	public List<Employee> findByEmpName(String ename);

	public List<Employee> findByOrgName(String ename);

}
