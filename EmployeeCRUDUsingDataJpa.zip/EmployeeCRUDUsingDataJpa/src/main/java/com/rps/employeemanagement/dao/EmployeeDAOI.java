package com.rps.employeemanagement.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.rps.employeemanagement.entity.Employee;
@Repository					//CRUDRepository
public interface EmployeeDAOI extends JpaRepository<Employee,Integer>{
	
	
	
	@Query("select e from Employee e where salary between ?1  and ?2")
	public List<Employee> getAllInBetween(long initialSal,long salary);

	public List<Employee> findByName(String ename);
	public List<Employee> findByCompany(String ename);
	//
	//public List<Employee> findBySalaryBetween(Integer initialSal,Integer salary);
	//

	
	
	
	
	
}
