package com.rps.employeemanagement.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rps.employeemanagement.dao.EmployeeDAOI;
import com.rps.employeemanagement.entity.Employee;

@Service
@Transactional
public class EmployeeService implements EmployeeServiceI {
	@Autowired
	EmployeeDAOI dao;

	public String EmployeeCreation(Employee emp) {
		Employee emp1 = dao.save(emp);
		if (emp1 != null)
			return "employee inserted successfully";
		else
			return "employee insertion failed";
	}

	public Employee getEmployeeById(int id) {
		Optional<Employee> emp1 = dao.findById(id);
		if (emp1.isPresent())
			return emp1.get();
		else
			return null;
	}

	public List<Employee> getAllEmployee() {
		return dao.findAll();
	}

	public String deleteByEmpId(int id) {
		 dao.deleteById(id);
		return "employee deleted...";
	}

	public String UpdateEmployee(Employee emp) {
		Employee emp1 = dao.save(emp);
		if (emp1 != null)
			return "employee updated successfully";
		else
			return "employee updation failed";
	}

	@Override
	public List<Employee> getAllEmpsInBetween(long initialSal, long salary) {
		
		return dao.getAllInBetween(initialSal, salary);
	}

	@Override
	public List<Employee> findByEmpName(String ename) {
		
		return dao.findByName(ename);
	}

	@Override
	public List<Employee> findByOrgName(String ename) {
		
		return dao.findByCompany(ename);
	}



}