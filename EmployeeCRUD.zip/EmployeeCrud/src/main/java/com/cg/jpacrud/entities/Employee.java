package com.cg.jpacrud.entities;



import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employees")
public class Employee implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="empId")
	private int employeeId;
	private String empName;
	private int empSal;
	private String address;
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public Employee(int employeeId, String empName, int empSal, String address) {
		super();
		this.employeeId = employeeId;
		this.empName = empName;
		this.empSal = empSal;
		this.address = address;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpSal() {
		return empSal;
	}
	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
